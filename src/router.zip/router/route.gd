class_name Route
extends Resource


func enter(ctx: RouterContext) -> RouterContext:
	return ctx

func process(ctx: RouterContext, _delta:=0.0) -> RouterContext:
	return ctx

func exit(ctx: RouterContext) -> RouterContext:
	return ctx
