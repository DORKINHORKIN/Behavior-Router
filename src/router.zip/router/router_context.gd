extends Resource
class_name RouterContext


@export var default_route_path := "/"
@export var route_map: Dictionary[String, Route] = {}


var paths: Array[String] = []

class RouteReference extends RefCounted:
	var route: Route = null
	var paths: Array[String] = []

    func _init(route: Route = null, paths: Array[String] = []):
        self.route = route
        self.paths = paths

var route: RouteReference = RouteReference.new()
var router: Router
var owner: Node
