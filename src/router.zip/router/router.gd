# router.gd
class_name Router
extends Node

@export var context: RouterContext

func _ready():
	if context == null:
		context = RouterContext.new()

	context.router = self
	context.owner = self

	set_route(context.default_route_path)

func _process(delta):
	if context.route and context.route.is_valid():
		process_paths(context.paths, delta)

# ---- Routing API ----

func get_route(path: String) -> RouterContext.RouteReference:
	var route = context.route_map.get(path)
	if route == null:
		return RouterContext.RouteReference.new(null, [], {})

	var paths = split_paths(path)
	var params = split_params(path)
	return RouterContext.RouteReference.new(route, paths, params)

func set_route(path: String) -> void:
	var new_ref = get_route(path)

	if not new_ref.is_valid():
		push_error("Route not found: " + path)
		return

	# exit current
	if context.route and context.route.is_valid():
		context.route.exit(context)

	# update context
	context.paths = new_ref.paths
	context.params = new_ref.params
	context.set_route_reference(new_ref)

	# enter + initial process
	for route_path in context.paths:
		var ref = get_route(route_path)
		if ref.is_valid():
			ref.enter(context)
			ref.process(context, 0.0)

func process_paths(paths: Array[String], delta: float) -> void:
	for path in paths:
		var ref = get_route(path)
		if ref.is_valid():
			ref.process(context, delta)

# ---- Utilities ----

static func split_paths(path: String) -> Array[String]:
	var walked := ""
	var paths: Array[String] = []

	for part in path.rsplit("/", false):
		if part == "":
			continue
		walked += "/" + part
		paths.append(walked)

	if paths.is_empty():
		paths.append("/")

	return paths

static func split_params(path: String) -> Dictionary[String, Variant]:
	var params: Dictionary[String, Variant] = {}

	for part in path.split("/", false):
		if part.begins_with(":"):
			var key_value = part.substr(1).split("=", false)
			var key = key_value[0]
			var value = key_value[1] if key_value.size() > 1 else ""
			params[key] = value

	return params

func has_route(path: String) -> bool:
	return context.route_map.has(path)

func add_route(path: String, route: Route) -> void:
	context.route_map[path] = route

func remove_route(path: String) -> void:
	context.route_map.erase(path)

func clear_routes() -> void:
	context.route_map.clear()
