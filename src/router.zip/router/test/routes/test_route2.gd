class_name TestRoute2
extends Route



func process(ctx: RouterContext, _delta := 0.0) -> RouterContext:
	if (!(ctx is CharacterRouterContext)):
		print("Context is not CharacterRouterContext")
		return ctx
	ctx = ctx as CharacterRouterContext



	return ctx
