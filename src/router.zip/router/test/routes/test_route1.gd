class_name TestRoute1
extends Route

func process(ctx: RouterContext, _delta := 0.0) -> RouterContext:
	print(path)

	return ctx
