class_name CharacterRouterContext
extends RouterContext

var character: Node = null