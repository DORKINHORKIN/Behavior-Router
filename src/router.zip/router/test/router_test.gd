extends Router
func _ready() -> void:
	super._ready()



func _process(delta: float) -> void:
	super._process(delta)

	var route_current = context["route_current"] as Route

	if (route_current):
		$Label.text = (context["route_current"]as Route).path
